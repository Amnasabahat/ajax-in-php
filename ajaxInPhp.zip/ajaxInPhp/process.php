<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "student";

// Create a connection to the database
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle data insertion if form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    
    // SQL query to insert data into the 'data' table
    $insert_sql = "INSERT INTO data (name, email, phone) VALUES ('amna', '2020gu0756', '03305368414')";
    
    if ($conn->query($insert_sql) === TRUE) {
        echo "New record inserted successfully";
    } else {
        echo "Error: " . $insert_sql . "<br>" . $conn->error;
    }
}

// SQL query to select all records from the 'data' table
$sql = "SELECT * FROM data";
$result = $conn->query($sql);

// Display records in an HTML table
if ($result->num_rows > 0) {
    echo "<table border='1'>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Action</th>
            </tr>";
    
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . $row["id"] . "</td>
                <td>" . $row["name"] . "</td>
                <td>" . $row["email"] . "</td>
                <td>" . $row["phone"] . "</td>
                <td>
                    <a href='edit.php?id=" . $row["id"] . "'>Edit</a>
                    <a href='delete.php?id=" . $row["id"] . "'>Delete</a>
                </td>
              </tr>";
    }
    
    echo "</table>";
} else {
    echo "No records found.";
}

// Close the database connection
$conn->close();
?>
